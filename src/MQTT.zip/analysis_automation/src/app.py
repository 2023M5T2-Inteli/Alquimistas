from models.base import Base
from threading import Thread
from datetime import datetime
from models.report import Report
from sqlalchemy import create_engine
from controllers.pdf_controller import PDF
from sqlalchemy.orm import Session, sessionmaker
from controllers.dobot_controller import Routine
from flask import Flask, render_template, redirect, request, jsonify
import jsonpickle
from flask_cors import CORS
import time
import utils.DobotDllType as DType
from controllers.publisher_controller import Cycle

PDF_WIDTH = 210
PDF_HEIGHT = 297
process = None

def Routine():
    print("aquiaqui")
    arm = Dobot(225, 3, 140, 0)
    arm.moveHome()
    arm.pickToggle()

    # #bandeja 1
    #self.cy.run()
    arm.moveArmXY(174, 222, 77, 51)
    arm.moveArmXY(265, 175, -11, 32)
    arm.moveArmXY(64, 169, -11, 67)
    arm.moveArmXY(276, 202, -11, 35)
    arm.moveArmXY(66, 195, -11, 69)
    arm.moveArmXY(268, 241, -11, 41)
    arm.moveArmXY(64, 271, -11, 75)
    arm.moveArmXY(260, 266, -11, 44)
    arm.moveArmXY(174, 222, 77, 51)

        # #bandeja 2
    arm.moveHome()
    arm.moveArmXY(325, -36, -8, -7)
    arm.rotateTool(-90)
    arm.moveArmXY(181, -18, -8, -6)
    arm.moveArmXY(313, 52, -8, 8)
    arm.rotateTool(-80)
    arm.moveArmXY(177, 43, -8, 12)
    arm.moveHome()

        # #bandeja 3
        #self.cy.stop()
    arm.moveArmXY(185, -229, 77, -51)
    arm.moveArmXY(185, -229, -10, -51)
    time.sleep(2)

app = Flask(__name__)
CORS(app)
header = []
engine = create_engine("sqlite+pysqlite:///reports.db", echo=True)
Session = sessionmaker(bind=engine)
session = Session()

Base.metadata.create_all(engine)

@app.route('/')
def index():
    return render_template('about.html')

@app.route('/home')
def home():
    return render_template('index.html')

@app.route('/report')
def report():
    return render_template('report.html')

@app.route('/routine')
async def control_on():
    global process
    try:
        process = Thread(target=Routine(), args=())
        process.start()
        process.join()
        return jsonpickle.encode('ok')
    
    except Exception as e:
        print("error")
        return f"ruim"

@app.route('/create_pdf', methods=["POST"])
async def post_form():
    print(request.form)
    header.clear()
    for i in request.form:
        header.append((i.capitalize(), request.form[i]))

    r1 = Report(project=request.form['projeto'], client=request.form['cliente'], sample=request.form['amostra'], operator=request.form['operador'],
                cycles=request.form['ciclos'], liquid_initial_mass=request.form['peso solido'], solid_initial_mass=request.form['peso solido'])

    session.add(r1)
    session.commit()
    return render_template('index.html', project=request.form['projeto'], client=request.form['cliente'], sample=request.form['amostra'])

@app.route('/export_pdf')
async def generate_pdf():
    pdf = PDF(orientation='P', unit='mm', format='A4')
    pdf.add_page()
    pdf.header()
    a = [10, 10]
    side = True
    for i in header:
        pdf.element(i[0] + ': ' + i[1], a, side)
        a[1] += 5 if (not side) else 0
        side = not side
    pdf.generate(datetime.now().strftime("%d-%m-%Y-%H%M%S"))
    return render_template("index.html")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)
