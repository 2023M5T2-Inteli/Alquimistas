# Intruções para rodar o projeto:

1º Abra o git bash na pasta do repositório

2º Instale as dependencias que estão no requirements.txt com o seguinte comando:

```pip install -r requirements.txt```

3º Instale as dependencias do broker:

```npm i```

4º Rode a aplicação com:

```./start.sh```
